(function( $ ) { 'use strict';

    $( document ).ready( function() {

        var BRCBackend = {

            init: function() {

            },
        };

        BRCBackend.init();
    });
})( jQuery );