<?php 

/**
 * Backend template for LCP
 */

if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class LCP_Backend
 */
class LCP_Backend {

    /**
     * @var self
     */
    private static $instance = null;

    /**
     * @since 1.0
     * @return $this
     */
    public static function instance() {

        if ( is_null( self::$instance ) && ! ( self::$instance instanceof LCP_Backend ) ) {
            self::$instance = new self;

            self::$instance->hooks();
        }

        return self::$instance;
    }

    /**
     * Define hooks
     */
    private function hooks() {

        add_action( 'admin_enqueue_scripts', [ $this, 'LCP_Backend_enqueue_scripts' ] );
        add_action( 'admin_menu', [ $this, 'lcp_add_progress_settings_submenu' ] );
        add_filter( 'plugin_action_links_'.LCP_BASE_DIR, [ $this, 'lcp_plugin_action_links' ] );
    }

    /**
     * Add a settings link to the plugin actions
     */
    public function lcp_plugin_action_links( $links ) {

        $settings_link = '<a href="'. admin_url( 'admin.php?page=lcp-progress-settings' ) .'">'. __( 'Settings', 'learndash-course-progress' ) .'</a>';
        array_unshift( $links, $settings_link );

        return $links;
    }

    /**
     * Hook to admin menu to create submenu under Learndash
     */
    public function lcp_add_progress_settings_submenu() {

        add_submenu_page(
            'learndash-lms',
            __( 'Progress Settings', 'learndash-course-progress' ),
            __( 'Progress Settings', 'learndash-course-progress' ),
            'manage_options',
            'lcp-progress-settings',
            [ $this, 'lcp_progress_settings_page_content' ]
        );
    }

    /**
     * Callback function for the submenu page content
     */
    public function lcp_progress_settings_page_content() {

        if (isset($_POST['lcp_save_settings'])) {

            if (check_admin_referer('lcp_progress_settings_nonce')) {
                update_option('lcp_general_color', sanitize_hex_color($_POST['lcp_general_color']));

                add_settings_error(
                    'lcp_progress_settings_messages',
                    'lcp_progress_settings_message',
                    __('Settings saved successfully.', 'lcp'),
                    'success'
                );
            } else {

                add_settings_error(
                    'lcp_progress_settings_messages',
                    'lcp_progress_settings_message',
                    __('Security check failed. Please try again.', 'lcp'),
                    'error'
                );
            }
        }

        settings_errors('lcp_progress_settings_messages');

        // Get saved options
        $lcp_general_color = get_option('lcp_general_color', '#00CD6A');

        ?>
        <div class="wrap lcp-setting-wrap">
            <h1><?php esc_html_e('Progress Settings', 'lcp'); ?></h1>
            <p><?php esc_html_e('Use this shortcode to display course progress:', 'lcp'); ?></p>
            <pre><code>[display_course_progress course_id=123]</code></pre>

            <form method="post" action="">
                <?php wp_nonce_field('lcp_progress_settings_nonce'); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="lcp_general_color"><?php esc_html_e('General Color', 'lcp'); ?></label></th>
                        <td>
                            <input type="text" name="lcp_general_color" value="<?php echo esc_attr($lcp_general_color); ?>" class="lcp-color-picker" />
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" name="lcp_save_settings" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'lcp'); ?>">
                </p>
            </form>
        </div>
        <?php
    }

    /**
     *  Frontend Enqueue script
     */
    public function LCP_Backend_enqueue_scripts() {

        $random_number = rand( 329423, 39284932 );

        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_style( 'LCP_Backend_style', LCP_ASSETS_URL.'css/backend.css', [], $random_number );
        wp_enqueue_script( 'LCP_Backend_js', LCP_ASSETS_URL.'js/backend.js', [ 'jquery' ], $random_number, true );

        wp_localize_script( 'LCP_Backend_js', 'CPS', 
            [
                'ajax_url' => admin_url( 'admin-ajax.php' )
            ] 
        );
    }
}

LCP_Backend::instance();