=== Learndash Course Progress ===
Contributors: Swrice, freemius  
Tags: learndash, course progress, learndash course progress, learndash customization, progress bar  
Requires at least: 6.3  
Tested up to: 6.3  
Requires PHP: 7.0  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  
Stable tag: trunk  

A lightweight and responsive LearnDash add-on that displays detailed course progress using a simple shortcode.

== Description ==

**Swrice LearnDash Course Progress Add-on** is a powerful and easy-to-use plugin that allows you to display student progress for any LearnDash course using a shortcode:

`[display_course_progress course_id=123]`

Replace `123` with the actual Course ID to show the relevant progress bar.

🎯 **Plugin Features**
- Easy-to-use shortcode: `[display_course_progress course_id=123]`
- Customizable general color to match your brand
- Responsive design: mobile, tablet, and desktop-friendly
- Widget-compatible: embed in sidebars or footer widget areas
- Lightweight and performance-optimized
- Compatible with all major LearnDash themes and templates

🚀 **How to Use**
1. Install and activate the plugin.
2. Go to **Settings > Learndash Course Progress**.
3. Choose your preferred general color.
4. Copy the shortcode provided.
5. Replace the course ID with the actual ID of your LearnDash course.
6. Paste the shortcode into any page, post, or widget area.

That’s it! Your course progress will now display in a clean, visual format.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/learndash-course-progress/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to **Settings > Learndash Course Progress** to configure your general color and get the shortcode.
4. Insert the shortcode on any page, post, or widget to show course progress.

== Frequently Asked Questions ==

= Can I show progress for multiple courses? =  
Yes, simply use the shortcode multiple times with different course IDs.

= Does the plugin work with all LearnDash themes? =  
Yes, the plugin is designed to be compatible with all major LearnDash themes and templates.

= Is this plugin mobile responsive? =  
Absolutely. The progress bar layout adjusts to fit all screen sizes.

== Screenshots ==
1. Admin settings page to customize colors
2. Frontend course progress bar
3. Example of widget integration

== Upgrade Notice ==

- Upcoming support for Gutenberg blocks.
- Enhanced dynamic user interaction features.
- Advanced customization options for deeper control.

== Changelog ==

= 1.0 =
* Initial release with shortcode support and color customization.

== Support ==

Need help or have questions? Our dedicated support team is here to help you make the most of this plugin. [Click here to contact us](https://www.swrice.com).