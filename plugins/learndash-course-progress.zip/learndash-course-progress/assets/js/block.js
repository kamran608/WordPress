const { registerBlockType } = wp.blocks;
const { createElement, Fragment, useEffect, useState } = wp.element;
const { TextControl, Spinner } = wp.components;

registerBlockType('lpc-course-progress/course-progress', {
    title: 'LPC Course Progress',
    icon: 'chart-bar',
    category: 'widgets',
    attributes: {
        courseId: {
            type: 'number',
            default: 0,
        },
        userId: {
            type: 'number',
            default: 0,
        },
    },
    edit: (props) => {
        const {
            attributes: { courseId, userId },
            setAttributes
        } = props;

        const [previewHtml, setPreviewHtml] = useState('');
        const [loading, setLoading] = useState(false);

        // Fetch shortcode output when courseId or userId changes
        useEffect(() => {
            const formData = new window.FormData();
            formData.append('action', 'lpc_render_shortcode');
            formData.append('course_id', courseId);
            formData.append('user_id', userId);

            setLoading(true);

            fetch(ajaxurl, {
                method: 'POST',
                body: formData,
            })
                .then((res) => res.text())
                .then((html) => {
                    setPreviewHtml(html);
                    setLoading(false);
                });
        }, [courseId, userId]);

        return createElement(Fragment, null,
            createElement(TextControl, {
                label: 'Course ID',
                value: courseId,
                type: 'number',
                onChange: (val) => {
                    const parsed = parseInt(val);
                    setAttributes({ courseId: isNaN(parsed) ? 0 : parsed });
                }
            }),
            createElement(TextControl, {
                label: 'User ID',
                value: userId,
                type: 'number',
                onChange: (val) => {
                    const parsed = parseInt(val);
                    setAttributes({ userId: isNaN(parsed) ? 0 : parsed });
                }
            }),
            createElement('p', null, 'Live Preview:'),
            loading
                ? createElement(Spinner, null)
                : createElement('div', {
                    dangerouslySetInnerHTML: { __html: previewHtml },
                    style: { background: '#f9f9f9', padding: '10px', border: '1px solid #ddd' }
                })
        );
    },
    save: () => null
});

// const { registerBlockType } = wp.blocks;
// const { createElement, Fragment } = wp.element;
// const { TextControl } = wp.components;

// registerBlockType('lpc-course-progress/course-progress', {
//     title: 'LPC Course Progress',
//     icon: 'chart-bar',
//     category: 'widgets',
//     attributes: {
//         courseId: {
//             type: 'number',
//             default: 0,
//         },
//         userId: {
//             type: 'number',
//             default: 0,
//         },
//     },
//     edit: (props) => {
//         const {
//             attributes: { courseId, userId },
//             setAttributes
//         } = props;

//         return createElement(Fragment, null,
//             createElement(TextControl, {
//                 label: 'Course ID',
//                 value: courseId,
//                 type: 'number',
//                 onChange: (val) => {
//                     const parsed = parseInt(val);
//                     setAttributes({ courseId: isNaN(parsed) ? 0 : parsed });
//                 }
//             }),
//             createElement(TextControl, {
//                 label: 'User ID',
//                 value: userId,
//                 type: 'number',
//                 onChange: (val) => {
//                     const parsed = parseInt(val);
//                     setAttributes({ userId: isNaN(parsed) ? 0 : parsed });
//                 }
//             }),
//             createElement('p', null, 'Shortcode Preview:'),
//             createElement('code', null, `[lpc_course_progress course_id="${courseId}" user_id="${userId}"]`)
//         );
//     },
//     save: () => null
// });